import { ChevronDown, ChevronRight, FileText, LoaderCircle } from 'lucide-react'
import { useState } from 'react'
import type { AgentIdentity, ArtifactRouter, ConversationScene, ProductBlockActionHandler, ProductBlockRenderer } from './types'

const ignoreProductBlockAction: ProductBlockActionHandler = () => undefined

export function ConversationFlow({ scene, identity, openArtifact, renderProductBlock, onProductBlockAction }: { scene: ConversationScene; identity: AgentIdentity; openArtifact: ArtifactRouter; renderProductBlock?: ProductBlockRenderer; onProductBlockAction?: ProductBlockActionHandler }) {
  return <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col gap-10 py-3">{scene.turns.map((turn, index) => <ConversationTurn key={turn.id} scene={scene} turnIndex={index} identity={identity} openArtifact={openArtifact} renderProductBlock={renderProductBlock} onProductBlockAction={onProductBlockAction ?? ignoreProductBlockAction} />)}</div>
}

function ConversationTurn({ scene, turnIndex, identity, openArtifact, renderProductBlock, onProductBlockAction }: { scene: ConversationScene; turnIndex: number; identity: AgentIdentity; openArtifact: ArtifactRouter; renderProductBlock?: ProductBlockRenderer; onProductBlockAction: ProductBlockActionHandler }) {
  const turn = scene.turns[turnIndex]
  const [open, setOpen] = useState(turn.execution?.status === 'running')
  return <section className="space-y-5 text-[15px] leading-6">
    <div className="ml-auto max-w-[85%] rounded-2xl bg-primary-bg px-4 py-3 text-foreground">{turn.user.content}</div>
    <div className="space-y-5">
      <div className="flex items-center gap-2 font-medium"><span className="flex size-6 items-center justify-center rounded-full bg-muted text-xs">{identity.name.slice(0, 1)}</span>{identity.name}</div>
      {turn.execution ? <div className="rounded-xl border border-border bg-card text-sm leading-5"><button type="button" onClick={() => setOpen((value) => !value)} className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left hover:bg-accent"><span className={turn.execution.status === 'running' ? 'text-primary' : 'text-success'}>{turn.execution.status === 'running' ? <LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" /> : <ChevronRight className="size-4" />}</span><span className="flex-1">{turn.execution.summary}</span>{open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}</button>{open && <ol className="space-y-2 border-t border-border px-3 py-2 text-muted-foreground">{turn.execution.steps?.map((step) => <li key={step.id}><p>{step.title}</p>{step.detail && <p className="text-xs">{step.detail}</p>}{step.actions?.map((action) => action.target ? <button key={action.id} type="button" className="mt-1 inline-flex text-xs text-primary hover:underline" onClick={() => openArtifact(action.target!)}>{action.label}</button> : <span key={action.id} className="mt-1 inline-flex text-xs">{action.label}</span>)}</li>)}</ol>}</div> : null}
      {turn.assistant ? <div className="space-y-3"><p className="text-foreground">{turn.assistant.content}</p>{turn.assistant.artifacts?.map((artifact) => <button key={artifact.id} type="button" onClick={() => openArtifact(artifact)} className="flex w-full items-center gap-2 rounded-xl border border-border bg-card p-3 text-left text-sm hover:bg-accent"><FileText className="size-4 text-primary" /><span>{artifact.title}</span></button>)}</div> : null}
      {turn.productBlocks?.map((block) => renderProductBlock?.(block, { turnId: turn.id, isLatestTurn: turnIndex === scene.turns.length - 1, openArtifact, onAction: onProductBlockAction }) ?? null)}
    </div>
  </section>
}
